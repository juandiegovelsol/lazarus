import React from "react";
import ExportButtonView from "./ExportButtonView";

const ExportButtonController = ({ devices }) => {
  const handleExport = () => {
    const csvData = devices.map((device) => {
      return [
        device.month,
        device.name,
        device.energy,
        device.hours,
        device.quantity,
        (device.energy * device.hours * device.quantity * 30) / 1000,
      ].join(",");
    });

    const csvHeader =
      "Month,Device Name,Energy (Wh),Hours/Day,Quantity,Monthly Energy (KWh)";
    const csvContent = csvHeader + "\n" + csvData.join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "energy_data.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return <ExportButtonView handleExport={handleExport} />;
};

export default ExportButtonController;
