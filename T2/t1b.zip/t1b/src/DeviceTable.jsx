import React from "react";

const calculateMonthlyEnergy = (device) => {
  const dailyWh = device.energy * device.hours * device.quantity;
  const monthlyWh = dailyWh * 30;
  const monthlykWh = monthlyWh / 1000;
  return monthlykWh.toFixed(2);
};

const DeviceTable = ({ devices }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Device Name</th>
          <th>Energy (Wh)</th>
          <th>Hours/Day</th>
          <th>Quantity</th>
          <th>Monthly Energy (KWh)</th>
        </tr>
      </thead>
      <tbody>
        {devices.map((device, index) => (
          <tr key={index}>
            <td>{device.name}</td>
            <td>{device.energy}</td>
            <td>{device.hours}</td>
            <td>{device.quantity}</td>
            <td>{calculateMonthlyEnergy(device)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default DeviceTable;
