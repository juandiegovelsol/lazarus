import React, { useState } from "react";
import MonthSelectorView from "./MonthSelectorView";

const MonthSelectorController = ({ onMonthSelect }) => {
  const [selectedMonth, setSelectedMonth] = useState("January");

  const handleMonthSelect = (month) => {
    setSelectedMonth(month);
    onMonthSelect(month);
  };

  return (
    <MonthSelectorView
      selectedMonth={selectedMonth}
      handleMonthSelect={handleMonthSelect}
    />
  );
};

export default MonthSelectorController;
