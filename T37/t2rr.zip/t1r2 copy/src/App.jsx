import React from "react";
import StoryContainer from "./components/StoryContainer";

function App() {
  return (
    <div>
      <StoryContainer />
    </div>
  );
}

export default App;
