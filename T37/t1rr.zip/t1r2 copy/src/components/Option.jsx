import React from "react";
import "./Option.css";
import Button from "./Button";

const Option = ({
  option,
  makeChoice,
  previousOptions,
  chosenOptions,
  disabled,
}) => {
  const handleChoose = () => {
    if (!disabled) {
      makeChoice(option.next);
    }
  };
  console.log("Option, ", option, "Chosen", chosenOptions, previousOptions);

  if (disabled) {
    return (
      <Button
        text={option.choice}
        onClick={handleChoose}
        className={`option-btn ${
          chosenOptions.includes(option.next) ? "chosen" : "not-chosen"
        }`}
        disabled={disabled}
      />
    );
  }

  return (
    <Button
      text={option.choice}
      onClick={handleChoose}
      className={`option-btn ${
        chosenOptions.includes(option.next) ? "chosen" : ""
      } ${
        previousOptions.includes(option.next) &&
        !chosenOptions.includes(option.next)
          ? "not-chosen"
          : ""
      }`}
      disabled={disabled}
    />
  );
};

export default Option;
