import React, { useState } from "react";
import ProductList from "./ProductList";
import Cart from "./Cart";
import RecommendedItems from "./RecommendedItems";
import ProductForm from "./ProductForm";

function App() {
  const [products, setProducts] = useState([
    { id: 1, name: "Smartphone", price: 599.99, category: "electronics" },
    { id: 2, name: "Laptop", price: 999.99, category: "electronics" },
    { id: 3, name: "T-shirt", price: 19.99, category: "clothing" },
    { id: 4, name: "Jeans", price: 49.99, category: "clothing" },
    { id: 5, name: "JavaScript Book", price: 29.99, category: "books" },
    { id: 6, name: "Python Book", price: 34.99, category: "books" },
  ]);

  const [cart, setCart] = useState([]);
  const [recommendedItems, setRecommendedItems] = useState([]);

  const addToCart = (id) => {
    const product = products.find((p) => p.id === id);
    if (product) {
      const existingProduct = cart.find((p) => p.id === id);
      if (existingProduct) {
        existingProduct.quantity = (existingProduct.quantity || 1) + 1;
      } else {
        cart.push({ ...product, quantity: 1 });
      }
      setCart([...cart]);
      updateRecommendedItems();
    }
  };

  const updateQuantity = (id, quantity) => {
    const product = cart.find((p) => p.id === id);
    if (product) {
      product.quantity = parseInt(quantity);
      if (product.quantity <= 0) {
        cart = cart.filter((p) => p.id !== id);
      }
      setCart([...cart]);
      updateRecommendedItems();
    }
  };

  const removeFromCart = (id) => {
    cart = cart.filter((p) => p.id !== id);
    setCart([...cart]);
    updateRecommendedItems();
  };

  const updateRecommendedItems = () => {
    const categories = {};
    cart.forEach((item) => {
      categories[item.category] = (categories[item.category] || 0) + 1;
    });
    const leastPopularCategory = Object.keys(categories).reduce((a, b) => {
      return categories[a] < categories[b] ? a : b;
    });
    const recommendedItems = products.filter(
      (p) =>
        p.category === leastPopularCategory && !cart.find((c) => c.id === p.id)
    );
    setRecommendedItems(recommendedItems.slice(0, 3));
  };

  const addProduct = (product) => {
    const normalizedName = product.name
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim()
      .split(" ")
      .sort()
      .join(" ");
    const productExists = products.some((p) => {
      const normalizedPName = p.name
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim()
        .split(" ")
        .sort()
        .join(" ");
      return normalizedPName === normalizedName;
    });
    if (!productExists) {
      product.id = products.length + 1;
      setProducts([...products, product]);
    }
  };

  return (
    <div>
      <ProductList products={products} addToCart={addToCart} />
      <Cart
        cart={cart}
        updateQuantity={updateQuantity}
        removeFromCart={removeFromCart}
      />
      <RecommendedItems recommendedItems={recommendedItems} />
      <ProductForm addProduct={addProduct} />
    </div>
  );
}

export default App;
