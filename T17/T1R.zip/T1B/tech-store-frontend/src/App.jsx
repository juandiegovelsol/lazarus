// src/App.js
import React from "react";
import DeviceForm from "./DeviceForm";

const App = () => {
  return (
    <div>
      <DeviceForm />
    </div>
  );
};

export default App;
