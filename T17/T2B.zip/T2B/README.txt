To test this code you first must access to the tech-store-backend folder in the console, and execute the
following commands on separate lines:

1. npm i
2. node server.js

Then, on a different console, you must access to the tech-store-frontend folder and execute the following
commands on separate lines:

1. npm i
2. npm run dev

Once the front and back are running access to the localhost:5173 in the browser