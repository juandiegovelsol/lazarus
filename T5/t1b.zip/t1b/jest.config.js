module.exports = {
  preset: "default",
  testEnvironment: "node",
  roots: ["<rootDir>"],
  testMatch: ["**/*.test.js"],
};
