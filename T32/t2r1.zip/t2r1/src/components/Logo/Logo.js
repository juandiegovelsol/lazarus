import React from "react";
import "./Logo.css";

const Logo = () => {
  return <div className="logo">Logo</div>;
};

export default Logo;
