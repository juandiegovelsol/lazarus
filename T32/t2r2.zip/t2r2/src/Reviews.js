import React, { useState, useEffect } from "react";
import "./Reviews.css";
import Card from "./Card";

const Reviews = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const reviewsElement = document.querySelector(".reviews-container");
      const rect = reviewsElement.getBoundingClientRect();
      if (rect.top <= window.innerHeight && rect.bottom >= 0) {
        setShow(true);
      }
    };

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("load", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("load", handleScroll);
    };
  }, []);

  return (
    <section className="reviews">
      <div className="reviews-container">
        <Card show={show} />
        <Card show={show} />
        <Card show={show} />
      </div>
    </section>
  );
};

export default Reviews;
