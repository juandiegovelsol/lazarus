import React, { useState, useEffect } from "react";
import "./Welcome.css";

const Welcome = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const welcomeElement = document.querySelector(".welcome-container");
      const rect = welcomeElement.getBoundingClientRect();
      if (rect.top <= window.innerHeight && rect.bottom >= 0) {
        setShow(true);
      }
    };

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("load", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("load", handleScroll);
    };
  }, []);

  return (
    <section className="welcome">
      <div className="welcome-container">
        <h1 className={`welcome-header ${show ? "show" : "hidden"}`}>
          Welcome to our landing page
        </h1>
        <button className={`welcome-button ${show ? "show" : "hidden"}`}>
          Learn More
        </button>
      </div>
    </section>
  );
};

export default Welcome;
