// src/models/Ticket.js
class Ticket {
  constructor(id, appName, grade, feedback) {
    this.id = id;
    this.appName = appName;
    this.grade = grade;
    this.feedback = feedback;
  }
}

export default Ticket;
