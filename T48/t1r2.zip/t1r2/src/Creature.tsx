import React from "react";
import ColorTooltip from "./ColorTooltip";

interface CreatureProps {
  headColor: string;
  bodyColor: string;
  legsColor: string;
  setHeadColor: (color: string) => void;
  setBodyColor: (color: string) => void;
  setLegsColor: (color: string) => void;
}

const Creature = ({
  headColor,
  bodyColor,
  legsColor,
  setHeadColor,
  setBodyColor,
  setLegsColor,
}: CreatureProps) => {
  const handleColorChange = (part: string, color: string) => {
    if (part === "head") {
      setHeadColor(color);
    } else if (part === "body") {
      setBodyColor(color);
    } else if (part === "legs") {
      setLegsColor(color);
    }
  };

  return (
    <div className="creature" id="creature">
      <div
        className="head"
        style={{ backgroundColor: headColor }}
      >
        <ColorTooltip
          part="head"
          color={headColor}
          setColor={(color) => handleColorChange("head", color)}
        />
      </div>
      <div
        className="body"
        style={{ backgroundColor: bodyColor }}
      >
        <ColorTooltip
          part="body"
          color={bodyColor}
          setColor={(color) => handleColorChange("body", color)}
        />
      </div>
      <div
        className="legs left-leg"
        style={{ backgroundColor: legsColor }}
      >
        <ColorTooltip
          part="legs"
          color={legsColor}
          setColor={(color) => handleColorChange("legs", color)}
        />
      </div>
      <div
        className="legs right-leg"
        style={{ backgroundColor: legsColor }}
      />
    </div>
  );
};

export default Creature;
