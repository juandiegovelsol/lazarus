Open the folder using Visual Studio code.
Right-click on the HTML file and select the preview option.