import React from "react";

const MenuButton = () => {
  return <button className="menu-button">Menu</button>;
};

export default MenuButton;
