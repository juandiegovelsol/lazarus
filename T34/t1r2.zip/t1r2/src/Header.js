import React from "react";
import MenuButton from "./MenuButton";

const Header = () => {
  return (
    <div className="header">
      <MenuButton />
    </div>
  );
};

export default Header;
