import React, { useState } from "react";
import MenuItem from "./MenuItem";
import CloseButton from "./CloseButton";

const Menu = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`menu ${isOpen ? "open" : ""}`}>
      <ul>
        <MenuItem href="#section1">Section 1</MenuItem>
        <MenuItem href="#section2">Section 2</MenuItem>
        <MenuItem href="#section3">Section 3</MenuItem>
      </ul>
      <CloseButton onClick={handleToggle} />
    </div>
  );
};

export default Menu;
