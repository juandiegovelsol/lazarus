import React from "react";
import Layout from "./Layout";
import "./App.css";

const App = () => {
  return <Layout />;
};

export default App;
