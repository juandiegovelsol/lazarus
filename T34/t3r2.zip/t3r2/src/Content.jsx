import React from "react";
import { Routes, Route } from "react-router-dom";
import CharacterSection from "./CharacterSection";
import "./Content.css";

const Content = () => {
  return (
    <div className="content">
      <Routes>
        <Route path="/:id" element={<CharacterSection />} />
      </Routes>
    </div>
  );
};

export default Content;
