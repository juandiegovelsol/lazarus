import React, { useState, useEffect } from "react";

interface Payment {
  month: number;
  dueAmount: number;
  payment: number;
}

interface LoanTableProps {
  loanAmount: number;
  interestRate: number;
  term: number;
}

const LoanTable: React.FC<LoanTableProps> = ({
  loanAmount,
  interestRate,
  term,
}) => {
  const [payments, setPayments] = useState<Payment[]>([]);

  const monthlyRate = interestRate / 100 / 12;
  const monthlyPayment =
    (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -term));

  const initializePayments = () => {
    const initialPayments = Array.from({ length: term }, (_, index) => ({
      month: index + 1,
      dueAmount: monthlyPayment,
      payment: 0,
    }));
    setPayments(initialPayments);
  };

  useEffect(() => {
    initializePayments();
  }, []);

  const handlePaymentChange = (month: number, payment: number) => {
    setPayments((prevPayments) => {
      const newPayments = [...prevPayments];
      newPayments[month - 1].payment = payment;
      for (let i = month; i < newPayments.length; i++) {
        const previousDueAmount = newPayments[i - 1].dueAmount;
        const previousPayment = newPayments[i - 1].payment;
        newPayments[i].dueAmount = Math.max(
          0,
          previousDueAmount - previousPayment
        );
      }
      return newPayments;
    });
  };

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>Month</th>
            <th>Due Amount</th>
            <th>Payment</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((p) => (
            <tr key={p.month}>
              <td>{p.month}</td>
              <td>{p.dueAmount.toFixed(2)}</td>
              <td>
                <input
                  type="number"
                  value={p.payment}
                  onChange={(e) =>
                    handlePaymentChange(p.month, Number(e.target.value))
                  }
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default LoanTable;
