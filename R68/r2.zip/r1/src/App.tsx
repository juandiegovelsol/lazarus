import React from 'react';
import SongManagementApp from './SongManagementApp';

const App = () => {


  return (
    <SongManagementApp/>
  );
};

export default App;
