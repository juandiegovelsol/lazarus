import React, { useState, useEffect } from 'react';

// Song interface
interface Song {
  id: number;
  name: string;
  duration: number;
  price: number;
}

// Predefined list of available songs
const availableSongs: Song[] = [
  { id: 1, name: 'Song 1', duration: 180, price: 10 },
  { id: 2, name: 'Song 2', duration: 240, price: 15 },
  { id: 3, name: 'Song 3', duration: 300, price: 20 },
];

const App = () => {
  // State to store purchased songs
  const [purchasedSongs, setPurchasedSongs] = useState<Song[]>([]);
  // State to store wallet balance
  const [balance, setBalance] = useState<number>(100);
  // State to store countdown for each song
  const [countdowns, setCountdowns] = useState<{ [id: number]: number }>({});

  // Function to purchase a song
  const purchaseSong = (song: Song) => {
    if (balance >= song.price) {
      setBalance(balance - song.price);
      setPurchasedSongs([...purchasedSongs, song]);
    } else {
      alert('Insufficient balance');
    }
  };

  // Function to start a song
  const startSong = (song: Song) => {
    setCountdowns({ ...countdowns, [song.id]: song.duration });
  };

  // Update countdowns every second
  useEffect(() => {
    const intervalId = setInterval(() => {
      const newCountdowns = { ...countdowns };
      Object.keys(countdowns).forEach((id) => {
        if (newCountdowns[id] > 0) {
          newCountdowns[id]--;
        } else {
          delete newCountdowns[id];
        }
      });
      setCountdowns(newCountdowns);
    }, 1000);
    return () => clearInterval(intervalId);
  }, [countdowns]);

  return (
    <div>
      <h1>Song Management App</h1>
      <h2>Wallet Balance: ${balance}</h2>
      <h2>Purchased Songs:</h2>
      <ul>
        {purchasedSongs.map((song) => (
          <li key={song.id}>
            {song.name}{' '}
            {countdowns[song.id] !== undefined ? (
              <button>
                {Math.floor(countdowns[song.id] / 60)}:
                {countdowns[song.id] % 60.toString().padStart(2, '0')}
              </button>
            ) : (
              <button onClick={() => startSong(song)}>Start</button>
            )}
          </li>
        ))}
      </ul>
      <h2>Available Songs:</h2>
      <ul>
        {availableSongs.map((song) => (
          <li key={song.id}>
            {song.name} - ${song.price}{' '}
            <button onClick={() => purchaseSong(song)}>Purchase</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
