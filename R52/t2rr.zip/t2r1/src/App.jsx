import FdrTable from "./FdrTable";

function App() {
  return (
    <>
      <FdrTable />
    </>
  );
}

export default App;
