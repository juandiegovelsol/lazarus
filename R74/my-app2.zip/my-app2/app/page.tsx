// app/page.tsx
"use client";

import { useState } from "react";
import { useOptimistic, useActionData, useServerInsertedHTML } from "next/app";
import {
  addTodoAction,
  deleteTodoAction,
  getTodos,
} from "./actions/todoActions";

export default function TodoList() {
  const [text, setText] = useState("");
  const todos = useOptimistic(getTodos, []);

  const handleAddTodo = async () => {
    if (!text) return;

    // Optimistic update: add todo locally before server confirms
    todos.mutate((todos) => [
      ...todos,
      { id: Date.now(), text, completed: false },
    ]);

    // Add todo through server action
    await addTodoAction(text);

    setText("");
  };

  const handleDeleteTodo = async (id: number) => {
    // Optimistically remove the todo
    todos.mutate((todos) => todos.filter((todo) => todo.id !== id));

    await deleteTodoAction(id);
  };

  return (
    <div className="todo-list">
      <h1>Todo List</h1>

      <ul>
        {todos.data?.map((todo) => (
          <li key={todo.id}>
            <span>{todo.text}</span>
            <button onClick={() => handleDeleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>

      <form onSubmit={(e) => e.preventDefault()}>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button type="submit" onClick={handleAddTodo}>
          Add Todo
        </button>
      </form>
    </div>
  );
}
