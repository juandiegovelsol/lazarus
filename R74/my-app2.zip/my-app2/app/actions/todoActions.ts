// app/actions/todoActions.ts
import { revalidatePath } from "next/cache";

type Todo = { id: number; text: string; completed: boolean };

let todos: Todo[] = [
  { id: 1, text: "Learn Next.js", completed: false },
  { id: 2, text: "Build cool apps", completed: false },
];

export async function addTodoAction(text: string) {
  const newTodo = { id: Date.now(), text, completed: false };
  todos.push(newTodo);

  // Simulate server latency
  await new Promise((resolve) => setTimeout(resolve, 1000));

  revalidatePath("/"); // Revalidate page to fetch the new data
  return newTodo;
}

export async function deleteTodoAction(id: number) {
  todos = todos.filter((todo) => todo.id !== id);

  // Simulate server latency
  await new Promise((resolve) => setTimeout(resolve, 1000));

  revalidatePath("/");
  return id;
}

export async function getTodos() {
  return todos;
}