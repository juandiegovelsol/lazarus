import React from "react";
import Header from "./Header";
import Menu from "./Menu";
import Content from "./Content";
import { CharactersProvider } from "./CharactersContext";
import "./Layout.css";

const Layout = () => {
  return (
    <CharactersProvider>
      <Header />
      <Menu />
      <Content />
    </CharactersProvider>
  );
};

export default Layout;
