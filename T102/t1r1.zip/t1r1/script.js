// Get the table body element where rows will be added
const tableBody = document.querySelector("#investment-table tbody");

// Get the button element that triggers the addition of new rows
const addRowBtn = document.getElementById("add-row-btn");

/**
 * Creates a new table row with input fields for investment data.
 */
function createRow() {
  // Create a new table row element
  const row = document.createElement("tr");

  // Define the types of input fields for each column
  const columns = [
    "text", // Symbol
    "number", // Entry Price
    "number", // Stop Loss
    "number", // Take Profit 1
    "number", // Take Profit 2
    "number", // Take Profit 3
    "number", // Take Profit 4
    "number", // Take Profit 5
    "number", // Purchase Price
    "number", // Investment Amount
    "number", // Current Price
    "calculated", // Signal Progress (%)
    "calculated", // Profit/Loss
  ];

  // Create input fields for each column and add event listeners to calculate the row data
  columns.forEach((type, index) => {
    // Create a new table cell element
    const cell = document.createElement("td");

    // If the column type is 'text' or 'number', create an input field and add an event listener
    if (type === "text" || type === "number") {
      // Create a new input field element
      const input = document.createElement("input");
      input.type = type;

      // Add an event listener to calculate the row data when the input field value changes
      input.addEventListener("input", () => {
        // Check if the input value is a valid number (not negative)
        if (type === "number" && input.value < 0) {
          alert("Please enter a non-negative number.");
          input.value = "";
        } else {
          calculateRow(row);
        }
      });

      // Add the input field to the table cell
      cell.appendChild(input);
    } else {
      // If the column type is 'calculated', set the initial text content to a default value
      cell.textContent = index === 11 ? "0%" : "$0.00";
    }

    // Add the table cell to the table row
    row.appendChild(cell);
  });

  // Add the table row to the table body
  tableBody.appendChild(row);
}

/**
 * Calculates the signal progress and profit/loss for a given table row.
 * @param {HTMLElement} row The table row element to calculate data for.
 */
function calculateRow(row) {
  // Get all table cells in the row
  const cells = row.querySelectorAll("td");

  // Get the input field values for entry price, purchase price, current price, and investment amount
  const entryPrice = parseFloat(cells[1].querySelector("input").value) || 0;
  const purchasePrice = parseFloat(cells[8].querySelector("input").value) || 0;
  const currentPrice = parseFloat(cells[10].querySelector("input").value) || 0;
  const investmentAmount =
    parseFloat(cells[9].querySelector("input").value) || 0;

  // Calculate the signal progress if the purchase price is greater than 0
  if (purchasePrice > 0) {
    const progress = (currentPrice / entryPrice) * 100 - 100;
    cells[11].textContent = `${progress.toFixed(2)}%`;
  }

  // Calculate the profit/loss if the investment amount is greater than 0
  if (investmentAmount > 0) {
    const profitLoss =
      (currentPrice - purchasePrice) * (investmentAmount / purchasePrice);
    cells[12].textContent = `$${profitLoss.toFixed(2)}`;
  }
}

// Add an event listener to the 'Add Row' button to create a new table row
addRowBtn.addEventListener("click", createRow);

// Create an initial table row
createRow();
