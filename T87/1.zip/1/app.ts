import express, { Request, Response } from "express";

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Local storage of dishes
interface Dish {
  id: number;
  name: string;
  price: number;
  description: string;
  available: number;
}

const dishes: Dish[] = [
  {
    id: 1,
    name: "Spaghetti Carbonara",
    price: 12,
    description: "Classic Italian pasta",
    available: 10,
  },
  // ... other dishes
];

// Endpoint to get all dishes
app.get("/dishes", (req: Request, res: Response) => {
  res.json(dishes);
});

// Endpoint to create an order
interface OrderItem {
  id: number;
  quantity: number;
}

app.post("/order", (req: Request, res: Response) => {
  const { items }: { items: OrderItem[] } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res
      .status(400)
      .json({ error: "Invalid order format or empty order." });
  }

  let subtotal = 0;

  for (const item of items) {
    const dish = dishes.find((d) => d.id === item.id);

    if (!dish) {
      return res
        .status(404)
        .json({ error: `Dish with id ${item.id} not found.` });
    }

    if (dish.available < item.quantity) {
      return res
        .status(400)
        .json({ error: `Not enough quantity available for ${dish.name}.` });
    }

    const discount = item.quantity > 3 ? 0.05 : 0; // 5% discount for more than 3 items of the same dish
    const totalForDish = item.quantity * dish.price * (1 - discount);

    subtotal += totalForDish;

    // Update availability
    dish.available -= item.quantity;
  }

  res.json({
    message: "Order created successfully",
    total: subtotal,
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
