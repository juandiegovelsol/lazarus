import React from "react";
import "./keyboard-styles.css";

const Keyboard = () => {
  return (
    // Keyboard component JSX
    <div></div>
  );
};

export default Keyboard;
