import React, { useState, useEffect } from "react";
import "./keyboard-styles.css";
import CryptoJS from "crypto-js";

const Keyboard = () => {
  const [password, setPassword] = useState("");
  const [numbers, setNumbers] = useState([]);

  useEffect(() => {
    generateRandomNumbers();
  }, []);

  const generateRandomNumbers = () => {
    let nums = [];
    for (let i = 0; i < 10; i++) {
      nums.push(i);
    }
    // Shuffle the numbers array
    for (let i = nums.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      let temp = nums[i];
      nums[i] = nums[j];
      nums[j] = temp;
    }
    // Remove the last two numbers (for the blank cell and erase button)
    nums.pop();
    nums.pop();
    setNumbers(nums);
  };

  const handleNumberClick = (num) => {
    setPassword(password + num);
  };

  const handleEraseClick = () => {
    setPassword(password.slice(0, -1));
  };

  const handleSubmitClick = () => {
    // Encrypt the password using AES
    const encryptedPassword = CryptoJS.AES.encrypt(
      password,
      "secretKey"
    ).toString();
    console.log(encryptedPassword);
  };

  return (
    <div className="keyboard-container">
      <input
        type="password"
        value={password
          .split("")
          .map(() => "*")
          .join("")}
        readOnly
      />
      <div className="keyboard-grid">
        {numbers.slice(0, 3).map((num, index) => (
          <div
            key={index}
            className="cell"
            onClick={() => handleNumberClick(num)}
          >
            {num}
          </div>
        ))}
        {numbers.slice(3, 6).map((num, index) => (
          <div
            key={index}
            className="cell"
            onClick={() => handleNumberClick(num)}
          >
            {num}
          </div>
        ))}
        {numbers.slice(6, 9).map((num, index) => (
          <div
            key={index}
            className="cell"
            onClick={() => handleNumberClick(num)}
          >
            {num}
          </div>
        ))}
        <div className="cell blank-cell"></div>
        <div className="cell" onClick={() => handleNumberClick(numbers[9])}>
          {numbers[9]}
        </div>
        <div className="cell erase-button" onClick={handleEraseClick}>
          Erase
        </div>
      </div>
      <button className="submit-button" onClick={handleSubmitClick}>
        Submit
      </button>
    </div>
  );
};

export default Keyboard;
