import React from 'react'; import CustomKeyboard from './components/CustomKeyboard'; const App = () => { return <div><CustomKeyboard /></div>; }; export default App;
