import React from "react";
import Keyboard from "./components/Keyboard";

function App() {
  return (
    // App component JSX
    <div>
      <Keyboard />
    </div>
  );
}

export default App;
