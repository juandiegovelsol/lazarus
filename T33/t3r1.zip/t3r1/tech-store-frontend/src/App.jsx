import React, { useState, useEffect } from "react";
import LoginForm from "./LoginForm";
import DeviceForm from "./DeviceForm";

const App = () => {
  const [state, setState] = useState({
    user: null,
    devices: [],
    users: [],
    selectedUser: null,
    newRole: "",
    title: "",
    description: "",
    price: 0,
    quantity: 0,
    imageUrl: "",
    email: "",
    password: "",
    role: "",
    isLogin: true,
  });

  const handleFetchDevices = async () => {
    try {
      const response = await fetch("http://localhost:3000/api/devices");
      const devices = await response.json();
      setState((prev) => ({ ...prev, devices }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleFetchUsers = async () => {
    try {
      const response = await fetch("http://localhost:3000/api/users");
      const users = await response.json();
      setState((prev) => ({ ...prev, users }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:3000/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: state.email,
          password: state.password,
        }),
      });
      const userData = await response.json();
      setState((prev) => ({ ...prev, user: userData }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:3000/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: state.email,
          password: state.password,
          role: state.role,
        }),
      });
      const userData = await response.json();
      setState((prev) => ({ ...prev, user: userData }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = async () => {
    try {
      const response = await fetch("http://localhost:3000/api/logout", {
        method: "POST",
      });
      const data = await response.json();
      console.log(data);
      setState((prev) => ({ ...prev, user: null }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:3000/api/devices", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: state.title,
          description: state.description,
          price: state.price,
          quantity: state.quantity,
          imageUrl: state.imageUrl,
        }),
      });
      const newDevice = await response.json();
      setState((prev) => ({ ...prev, devices: [...prev.devices, newDevice] }));
      setState((prev) => ({
        ...prev,
        title: "",
        description: "",
        price: 0,
        quantity: 0,
        imageUrl: "",
      }));
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        `http://localhost:3000/api/users/${state.selectedUser.id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            role: state.newRole,
          }),
        }
      );
      const updatedUser = await response.json();
      setState((prev) => ({
        ...prev,
        users: prev.users.map((user) =>
          user.id === updatedUser.id ? updatedUser : user
        ),
      }));
      setState((prev) => ({ ...prev, selectedUser: null, newRole: "" }));
    } catch (error) {
      console.error(error);
    }
  };

  React.useEffect(() => {
    if (state.user) {
      handleFetchDevices();
      if (state.user.role === "admin") {
        handleFetchUsers();
      }
    }
  }, [state.user]);

  if (!state.user || state.user.message === "Invalid email or password") {
    return (
      <LoginForm
        state={state}
        setState={setState}
        handleLogin={handleLogin}
        handleRegister={handleRegister}
      />
    );
  }

  return (
    <DeviceForm
      state={state}
      setState={setState}
      handleLogout={handleLogout}
      handleSubmit={handleSubmit}
      handleUpdateUser={handleUpdateUser}
    />
  );
};

export default App;
