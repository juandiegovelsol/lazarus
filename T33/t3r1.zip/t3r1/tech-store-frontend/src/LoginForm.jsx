import React from "react";

const LoginForm = ({ state, setState, handleLogin, handleRegister }) => {
  return (
    <div>
      {state.isLogin ? (
        <form onSubmit={handleLogin}>
          <h1>Login</h1>
          <label>
            Email:
            <input
              type="email"
              value={state.email}
              onChange={(e) =>
                setState((prev) => ({ ...prev, email: e.target.value }))
              }
            />
          </label>
          <br />
          <label>
            Password:
            <input
              type="password"
              value={state.password}
              onChange={(e) =>
                setState((prev) => ({ ...prev, password: e.target.value }))
              }
            />
          </label>
          <br />
          <button type="submit">Login</button>
          <button
            type="button"
            onClick={() => setState((prev) => ({ ...prev, isLogin: false }))}
          >
            Register
          </button>
        </form>
      ) : (
        <form onSubmit={handleRegister}>
          <h1>Register</h1>
          <label>
            Email:
            <input
              type="email"
              value={state.email}
              onChange={(e) =>
                setState((prev) => ({ ...prev, email: e.target.value }))
              }
            />
          </label>
          <br />
          <label>
            Password:
            <input
              type="password"
              value={state.password}
              onChange={(e) =>
                setState((prev) => ({ ...prev, password: e.target.value }))
              }
            />
          </label>
          <br />
          <label>
            Role:
            <select
              value={state.role}
              onChange={(e) =>
                setState((prev) => ({ ...prev, role: e.target.value }))
              }
            >
              <option value="">Select a role</option>
              <option value="admin">Admin</option>
              <option value="customer">Customer</option>
            </select>
          </label>
          <br />
          <button type="submit">Register</button>
          <button
            type="button"
            onClick={() => setState((prev) => ({ ...prev, isLogin: true }))}
          >
            Login
          </button>
        </form>
      )}
    </div>
  );
};

export default LoginForm;
